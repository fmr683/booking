-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2017 at 11:27 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking-system`
--

-- --------------------------------------------------------

--
-- Table structure for table `addon`
--

CREATE TABLE `addon` (
  `id` int(10) UNSIGNED NOT NULL,
  `add_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_type` tinyint(4) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addon`
--

INSERT INTO `addon` (`id`, `add_name`, `day_type`, `price`, `created_at`, `updated_at`) VALUES
(1, 'Glass', 1, '1000.00', '2017-10-08 12:24:47', '2017-10-08 12:24:47'),
(2, 'Plate', 1, '1000.00', '2017-10-08 12:25:04', '2017-10-08 12:25:04'),
(3, 'Chicken Plate', 1, '10000.00', '2017-10-08 12:25:39', '2017-10-08 12:25:39'),
(4, 'Glass', 2, '100.00', '2017-10-08 12:26:02', '2017-10-08 12:26:02'),
(5, 'Plate', 2, '1000.00', '2017-10-08 12:26:28', '2017-10-08 12:26:28'),
(6, 'Chicken Plate', 2, '200.00', '2017-10-08 12:26:52', '2017-10-08 12:26:52'),
(7, 'Glass', 3, '100.00', '2017-10-08 12:27:27', '2017-10-08 12:27:27'),
(8, 'Plate', 3, '200.00', '2017-10-08 12:27:55', '2017-10-08 12:27:55'),
(9, 'Chicken Plate', 3, '300.00', '2017-10-08 12:28:11', '2017-10-08 12:28:11');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(10) UNSIGNED NOT NULL,
  `pm_id` int(10) UNSIGNED NOT NULL,
  `c_id` int(10) UNSIGNED NOT NULL,
  `h_total` decimal(10,2) NOT NULL,
  `add_total` decimal(10,2) NOT NULL,
  `day_type` tinyint(4) NOT NULL,
  `active` tinyint(4) NOT NULL COMMENT '// 1-Pending, 2-Completed, 3-Cancelled',
  `b_date` date NOT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `pm_id`, `c_id`, `h_total`, `add_total`, `day_type`, `active`, `b_date`, `discount`, `total`, `created_at`, `updated_at`) VALUES
(2, 1, 9, '60000.00', '2000.00', 1, 1, '2017-10-09', '10.00', '57000.00', '2017-10-08 13:25:42', '2017-10-08 14:18:43'),
(3, 11, 10, '160000.00', '1300.00', 2, 2, '2017-10-10', '0.00', '162400.00', '2017-10-08 14:22:37', '2017-10-08 14:22:37'),
(5, 7, 12, '110000.00', '1000.00', 1, 2, '2017-10-09', '0.00', '61000.00', '2017-10-08 15:42:21', '2017-10-08 15:42:21');

-- --------------------------------------------------------

--
-- Table structure for table `booking_addon`
--

CREATE TABLE `booking_addon` (
  `id` int(10) UNSIGNED DEFAULT NULL,
  `addon_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `booking_addon`
--

INSERT INTO `booking_addon` (`id`, `addon_id`) VALUES
(2, 1),
(2, 2),
(3, 4),
(3, 5),
(3, 6),
(5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `booking_payment`
--

CREATE TABLE `booking_payment` (
  `bpid` int(11) NOT NULL,
  `id` int(10) UNSIGNED NOT NULL,
  `payment_type` tinyint(4) NOT NULL COMMENT '// 1- Advance payment/2-Full payment',
  `paid_date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `booking_payment`
--

INSERT INTO `booking_payment` (`bpid`, `id`, `payment_type`, `paid_date`, `amount`) VALUES
(2, 2, 1, '2017-10-08', '25000.00'),
(3, 3, 2, '2017-10-08', '162400.00'),
(4, 5, 2, '2017-10-08', '61000.00');

-- --------------------------------------------------------

--
-- Table structure for table `booking_type`
--

CREATE TABLE `booking_type` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `booking_type`
--

INSERT INTO `booking_type` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Banquet (Down)', '2017-10-08 12:03:00', '2017-10-08 12:03:00'),
(2, 'Banquet (Up)', '2017-10-08 12:04:01', '2017-10-08 12:04:01'),
(3, 'Tent', '2017-10-08 12:09:56', '2017-10-08 12:10:09'),
(4, 'Reception 1', '2017-10-08 12:10:24', '2017-10-08 12:10:24'),
(5, 'Reception 2', '2017-10-08 12:10:36', '2017-10-08 12:10:36');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `c_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_number` int(10) NOT NULL,
  `c_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `c_name`, `c_number`, `c_address`, `created_at`, `updated_at`) VALUES
(9, 'Mubarak', 35345, 'sdfasdf s fdsf', '2017-10-08 19:48:43', '2017-10-08 14:18:43'),
(10, 'fazlul', 23423424, 'sdf asf asf', '2017-10-08 14:22:37', '2017-10-08 14:22:37'),
(12, 'qqeqqwe', 123123, 'dasdasd', '2017-10-08 15:42:21', '2017-10-08 15:42:21');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_10_01_144255_create_booking_type_table', 1),
(4, '2017_10_01_144537_create_addon_table', 1),
(5, '2017_10_01_144538_create_price_mapping_table', 1),
(6, '2017_10_01_144630_create_booking_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `price_mapping`
--

CREATE TABLE `price_mapping` (
  `id` int(10) UNSIGNED NOT NULL,
  `day_type` smallint(6) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `price_mapping`
--

INSERT INTO `price_mapping` (`id`, `day_type`, `price`, `created_at`, `updated_at`) VALUES
(1, 1, '60000.00', '2017-10-08 12:15:43', '2017-10-08 12:15:43'),
(2, 2, '60000.00', '2017-10-08 12:16:09', '2017-10-08 12:16:29'),
(3, 3, '65000.00', '2017-10-08 12:16:44', '2017-10-08 12:16:44'),
(4, 1, '80000.00', '2017-10-08 12:17:22', '2017-10-08 12:17:22'),
(5, 2, '80000.00', '2017-10-08 12:17:40', '2017-10-08 12:17:40'),
(6, 3, '85000.00', '2017-10-08 12:17:58', '2017-10-08 12:17:58'),
(7, 1, '110000.00', '2017-10-08 12:18:25', '2017-10-08 12:18:25'),
(8, 2, '110000.00', '2017-10-08 12:18:46', '2017-10-08 12:18:46'),
(9, 3, '115000.00', '2017-10-08 12:19:07', '2017-10-08 12:19:07'),
(10, 1, '160000.00', '2017-10-08 12:19:46', '2017-10-08 12:19:46'),
(11, 2, '160000.00', '2017-10-08 12:20:08', '2017-10-08 12:20:08'),
(12, 3, '165000.00', '2017-10-08 12:20:28', '2017-10-08 12:20:28');

-- --------------------------------------------------------

--
-- Table structure for table `price_mapping_btype`
--

CREATE TABLE `price_mapping_btype` (
  `id` int(10) UNSIGNED NOT NULL,
  `btype_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `price_mapping_btype`
--

INSERT INTO `price_mapping_btype` (`id`, `btype_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 2),
(5, 2),
(6, 2),
(7, 2),
(7, 1),
(8, 2),
(8, 1),
(9, 2),
(9, 1),
(10, 3),
(10, 2),
(10, 1),
(11, 3),
(11, 2),
(11, 1),
(12, 3),
(12, 2),
(12, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'fazlul', 'frm683@gmail.com', '$2y$10$eGOf9lXHMrXHMSbgXFRURevBq3OrUhjKsIob37N/30Mto.T3R8uPa', 's0T05ZewrFt6U8CQZIsKWu5klQyKrVdJpPUZd4mP6jXCvGObw0F6gzGTjC64', '2017-10-07 06:29:53', '2017-10-07 06:29:53'),
(3, 'fazlul', 'frm683frm683@gmail.com', '$2y$10$1C19hF0B/Cp//ti9DlTg8eBuJcmLHrNPjEeUXX5foclq6UYyWM6oq', NULL, '2017-10-07 06:50:39', '2017-10-07 06:50:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addon`
--
ALTER TABLE `addon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pm_id` (`pm_id`,`day_type`,`b_date`),
  ADD KEY `customer_fk` (`c_id`);

--
-- Indexes for table `booking_addon`
--
ALTER TABLE `booking_addon`
  ADD KEY `payment_fk` (`id`);

--
-- Indexes for table `booking_payment`
--
ALTER TABLE `booking_payment`
  ADD PRIMARY KEY (`bpid`),
  ADD KEY `booking_payment_id_foreign` (`id`);

--
-- Indexes for table `booking_type`
--
ALTER TABLE `booking_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `price_mapping`
--
ALTER TABLE `price_mapping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `price_mapping_btype`
--
ALTER TABLE `price_mapping_btype`
  ADD KEY `price_mapping_btype_id_foreign` (`id`),
  ADD KEY `price_mapping_btype_btype_id_foreign` (`btype_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addon`
--
ALTER TABLE `addon`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `booking_payment`
--
ALTER TABLE `booking_payment`
  MODIFY `bpid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `booking_type`
--
ALTER TABLE `booking_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `price_mapping`
--
ALTER TABLE `price_mapping`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_c_id_foreign` FOREIGN KEY (`c_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `booking_pm_id_foreign` FOREIGN KEY (`pm_id`) REFERENCES `price_mapping` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `customer_fk` FOREIGN KEY (`c_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `booking_addon`
--
ALTER TABLE `booking_addon`
  ADD CONSTRAINT `payment_fk` FOREIGN KEY (`id`) REFERENCES `booking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `booking_payment`
--
ALTER TABLE `booking_payment`
  ADD CONSTRAINT `booking_payment_id_foreign` FOREIGN KEY (`id`) REFERENCES `booking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `price_mapping_btype`
--
ALTER TABLE `price_mapping_btype`
  ADD CONSTRAINT `price_mapping_btype_btype_id_foreign` FOREIGN KEY (`btype_id`) REFERENCES `booking_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `price_mapping_btype_id_foreign` FOREIGN KEY (`id`) REFERENCES `price_mapping` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
